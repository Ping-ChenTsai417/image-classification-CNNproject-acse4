# ACSE 4.4 - Machine Learning Miniproject
# The Identification Game
### Project description
The goal of the project was to train a classifier for a dataset of Natural Images. The given dataset consisted of 200 categories of pictures and 500 pictures from each category were provided. Most images had 3 colour channels and were of the size 64x64, there were, however, occasional images which only had one colour channel.

In order to achieve the best performance we have successfuly implementend various classifiers such as: [DenseNet-201](unsuccessful_models/denseNet201.py), [ResNet50](ResNet50ep10.ipynb), ResNet100, ResNeXt-101,[ResNeXt-50](unsuccessful_models/resnext50_32x4d.py), [VGG-11](VGG11.ipynb) and AlexNet.

The two which we found the most successful were [ResNet50](ResNet50ep10.ipynb) and [VGG-11](VGG11.ipynb) (with batch normalisation). Feature extraction was used for ResNet50 because it was a very deep model and we had issues running it when finetuning it (such as memory limitations). On the other hand, VGG-11 is shallower, and we were able to finetune it. Given more resources, we would have chosen to finetune ResNet50 as this would have resulted in a higher f-score. 

#### ResNet50

For this model, we used a validation set consisting of 20% of the training set to find the best hyperparameters. This ratio provided the best f-scores and the split was created randomly (this less vigorous, compared to stratified spliting, method was used as it was less memory intensive). Images were resized from 64x64 to 224x224 as the original ResNet50 took in images of size 224x224.

Having tested several combinations, but also reading the paper describing the ResNet models (Deep Residual Learning for Image Recognition), we found that the following values provided the best results: 
```
momentum = 0.9 (this was the same as the paper)
weight_decay = 1e-2
learning_rate = 5e-3
batch_size = 128
test_batch_size = 500
optimizer = SGD (same as paper)
number of epochs = 10 (to run up to)
```
Choosing the number of epochs to run up to was also important in not only retrieving the best accuracies/f-scores, but also to reduce
overfitting of the model. We found that for ResNet 50, the validation accuracy flattened out after around 9 epochs, whilst training accuracy continued to rise. For VGG-11, described below, training accuracy eclipsed validation accuracy after around 4-5 epochs.

Deep Residual Learning for Image Recognition also described using an adaptive learning method whereby the learning rate would be divided
by ten everytime the gradient started to flatten. We managed to integrate a similar idea into our ResNet model by using the lr_scheduler function from pytorch. This function would be called when initialising the model. In the code below for example, the learning rate would be multiplied by 0.1 every 3 epochs. Unfortanutely, this method was not found to improve the validation accuracy (and f-score).
```
from torch.optim import lr_scheduler 
exp_lr_scheduler = lr_scheduler.StepLR(optimizer_ft, step_size=3, gamma=0.1) 
model_ft = train_model(model_ft, criterion, optimizer_ft, exp_lr_scheduler, num_epochs=25)

```

The results can be seen in the graph below:
![Example](figures/val_ResNet50.png)

As seen above, we were not able to produce the f-scores per epoch for ResNet50 due to memory limitations (however we were able to do it 
for a less deep network such as VGG-11, as seen below). 
Using the our best hyperparameters, we trained the model for 10 epochs using the entire training data set, reaching a training accuracy of 67%.
The results can be seen in the graph below:
![Example2](figures/test_ResNet50.png)

After training, we tested the results using the test set and obtained the test accuracy of 64%. 

#### VGG-11 (with batch normalisation)

VGG-11 used a 90:10 training/validation split as this provided the best f-scores. We introduced 2 data augmentation techniques: random rotations by up to 10 degrees and random horizontal flip (probability = 0.5). Images were not resized to the original input of VGG-11 (224) due to memory limitations. Ideally, we would have done resizing. We also changed and added additions to the last layer of VGG-11 as so:
```
Original last FCC layer:
nn.Linear(num_ftrs, num_classes)

Changed to:
 nn.Sequential(nn.Linear(num_ftrs,int(num_ftrs/4)), nn.PReLU(), nn.Linear(int(num_ftrs/4),num_classes))

```
These changes improved the f-score by a few percent. 

On the other hand, it should be noted that the images were not resized to 224 (what VGG-11 originally takes in) as this caused memory overflow, so the original size of 64 was kept. Despite this, we used a pretrained VGG-11 model as it provided the best results. For comparison, untrained VGG-11 had f-scores of around 20%, whilst the pretrained VGG-11 has f-scores around 60%.
We used a validation set consisting of 10% of the training set to find the best hyperparameters. The split was created using StratifiedShuffleSplit to create an even distribution of classes in the training and validation data sets. The following values provided the second best results we had: 
```
momentum = 0.5
weight_decay = 1e-3
learning_rate = 1e-3
batch_size = 20
test_batch_size = 64
optimizer = SGD (as used in the Simonyan and Zisserman (2015) paper about VGG)
number of epochs = 6 (to run up to)
```

The results of the training and validation accuracy can be seen in the graph below. As it can be seen on the graph, our VGG model also implements a function which calculates F1-score using the validation set. 
![Example](figures/val_F1_VGG.png)

Using the best hyperparameters, we then trained the model for 6 epochs using the entire training data set, reaching a training accuracy of 71%.
The results can be seen in the graph below:
![Example2](figures/test_VGG.png)

After training, we tested the results using the test set and obtained an f-score of 61%. 


### Requirements

Download Cuda 10 and run the following command:

```
pip install -r requirements.txt
```
### User instructions

Initialize the model, send model to the GPU and choose the parameters to be optmized
```
resnet50 = initialize_model(num_classes, use_pretrained=True)
resnet50 = resnet50.to(device)
params_to_update = resnet50.parameters()

```
Define the optimizer and loss function used for training 
```
optimizer_ft = optim.SGD(params_to_update, lr=lr, momentum=momentum)
criterion = nn.CrossEntropyLoss()
```

Run the training on the training set and validation set in order to test the hyperparameters
```
model = train_pret_model(momentum)
```
After choosing the best hyperparameters, reinitialize the the model, define the new optimizer and loss function and then run the training on the whole test set. 

```
resnet50 = initialize_model(num_classes, use_pretrained=True)
resnet50 = resnet50.to(device)
params_to_update = resnet50.parameters()
optimizer_ft = optim.SGD(params_to_update, lr=lr, momentum=momentum)
criterion = nn.CrossEntropyLoss()
model = full_train(momentum)
```
And finally use the evaluate function to predict the labels of the test set.
```
y_pred = evaluate(model, test_loader)
```

### Documentation

There is sphinx documentation available for both models:
[ResNet50](./source/sfinx_build/ResNet50ep10.html#module-python_models.ResNet50ep10)
[VGG-11](./source/sfinx_build/ResNet50ep10.html#module-python_models.VGG11)


### References:

He, K., Zhang, X., Ren, S. and Sun, J. (2015). Deep Residual Learning for Image Recognition. Computer Vision and Pattern Recognition. [online] Available at: https://arxiv.org/abs/1512.03385 [Accessed 22 May 2020].

Very Deep Convolutional Networks for Large-Scale Image Recognition. (2015). International Conference on Learning Representations, 2015. [online] Available at: https://www.robots.ox.ac.uk/~vgg/publications/2015/Simonyan15/simonyan15.pdf [Accessed 22 May 2020].
