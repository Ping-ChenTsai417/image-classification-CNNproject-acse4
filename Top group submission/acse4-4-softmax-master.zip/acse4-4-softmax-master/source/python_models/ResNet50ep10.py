#!/usr/bin/env python
# coding: utf-8

# In[1]:



import io
import os
import csv

from sklearn.metrics import accuracy_score

from livelossplot import PlotLosses
from pycm import *
from PIL import Image

import torch
import torchvision
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import torchvision.models as models
import torchvision.transforms as transforms

from torchvision.datasets import ImageFolder
from torch.utils.data import TensorDataset, DataLoader, random_split
#
#
## In[2]:
#
#
## setting up cuda if availble
#device = 'cpu'
#if torch.cuda.device_count() > 0 and torch.cuda.is_available():
#    print("Cuda installed! Running on GPU!")
#    device = 'cuda'
#else:
#    print("No GPU available!")
#
#
## In[3]:
#
#
## path to directory with train and test folder defined by user
#path = './data/'
#
#
## In[4]:
#
#
def set_seed(seed):
    """
    This function is used to set all the random seeds to a fixed value and take out any randomness from cuda kernels.

    Args:
        seed: An integer repersenting a fixed random seed.
    """
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

    torch.backends.cudnn.benchmark = False  ##uses the inbuilt cudnn auto-tuner to find the fastest convolution algorithms. -
    torch.backends.cudnn.enabled   = False

    return True

class CustomImageFolder(ImageFolder):
    """
    Custom ImageFolder class to store individual path and name of test image files in tuple. 
    Used only on the test data set to create the .csv file containing the name of test image files 
    and their predicted labels.
    
    Args:
        ImageFolder: A dataloader from the pytorch library to load images.
    """
    def __getitem__(self, index):
        
        # the original tuple created by pytorch ImageFolder function
        original_tuple = super(CustomImageFolder, self).__getitem__(index)
        
        # path of the test imags
        path = self.imgs[index][0]
        
        # adding the path of test images to a tuple
        new_tuple = (original_tuple + (path,))
        
        return new_tuple

#
## In[5]:
#
#
## means and stds of the full training data set (pre-calculated) in each channel (total of 3 channels as RGB)
## this is used to perform Z-normalization on the full training set
## The means and stds are from the pre-trained model of ResNet50 from the pytorch library
#means = [0.485, 0.456, 0.406]
#stds = [0.229, 0.224, 0.225]
#
## list of transforms to perform on the entire training set - the order matters
## 1. resize the PIL image from 64 to 224 as pretrained ResNet50 takes in images of size 224 with .Resize()
## 2. convert the PIL images into torch tensors using .ToTensor()
## 3. normalize every pixel per channel using .Normalize()
## can also add data augumentation transforms, but found that this reduced accuracy
#train_normalise = transforms.Compose([
#                    transforms.Resize(224),
#                    transforms.ToTensor(),
#                    transforms.Normalize(mean=np.array(means), std=np.array(stds))])
#
## list of transforms to perform on the entire test set - same as for training set but without data augumentation (if added before)
#test_normalise = transforms.Compose([
#                    transforms.Resize(224),
#                    transforms.ToTensor(),
#                    transforms.Normalize(mean=np.array(means), std=np.array(stds))])
#
## load training and test images with ImageFolder and CustomImageFolder respectively, and apply defined transforms
#full_data = ImageFolder(path+'train', transform=train_normalise)
#test_data_raw = CustomImageFolder(path+'test', transform=test_normalise)
#
#
## In[6]:
#
#
## setting up the train and validation split (80 training:20 validation)
#train_size = int(0.8 * len(full_data))
#validation_size = len(full_data) - train_size
#
## randomly split a dataset into non-overlapping new datasets of given the lengths
## uses less RAM then StratifiedShuffleSplit 
#train_dataset, validation_dataset = random_split(full_data, [train_size, validation_size])
#
## storing test data in an array
#test_dataset = np.array([v[0].numpy() for v in test_data_raw])
#
## batch size for training, validation and test
#batch_size = 128
#test_batch_size = 500
#
## setting up dataloaders for training, validation and test datasets
#train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=0)
#validation_loader = DataLoader(validation_dataset, batch_size=test_batch_size, shuffle=False, num_workers=0)
#test_loader = DataLoader(test_dataset, batch_size=test_batch_size, shuffle=False, num_workers=0)
#
#
## In[7]:
#
#
# function to optimize and train the model
def train(model, optimizer, criterion, data_loader):
    """
    Function to train a model on a training dataset.
    
    Args:
        model: The model to be trained.
        optimizer: Iterative method to reduce the loss function.
        criterion: The way in which the loss function is calculated.
        data_loader: Subsamples over the training dataset. 
    
    """
    model.train()
    train_loss, train_accuracy = 0, 0
    i = 0
    for X, y in data_loader:
        i += 1
        if i % 100 == 0:
            print(i)
            
        X, y = X.to(device), y.to(device)
        optimizer.zero_grad()
        a2 = model(X.view(-1, 3, 224, 224)) #modification described above
        loss = criterion(a2, y)
        loss.backward()
        train_loss += loss*X.size(0)
        y_pred = F.log_softmax(a2, dim=1).max(1)[1]
        train_accuracy += accuracy_score(y.cpu().numpy(), y_pred.detach().cpu().numpy())*X.size(0)
        optimizer.step()  
        
    return train_loss/len(data_loader.dataset), train_accuracy/len(data_loader.dataset)

# function to validate training model with validation dataset
def validate(model, criterion, data_loader):
    """
       Function that calculates the accuracy and log loss using a validation dataset.
    
    Args:
        model: A trained model. 
        criterion: The way in which the loss function is calculated.
        data_loader: Subsamples over the validation dataset. 
    
    """
    model.eval()
    validation_loss, validation_accuracy = 0., 0.
    
    for X, y in data_loader:
        with torch.no_grad():
            
            X, y = X.to(device), y.to(device)
            a2 = model(X.view(-1, 3, 224, 224)) #modification described above
            loss = criterion(a2, y)
            validation_loss += loss*X.size(0)
            y_pred = F.log_softmax(a2, dim=1).max(1)[1]
            validation_accuracy += accuracy_score(y.cpu().numpy(), y_pred.cpu().numpy())*X.size(0)
            
    return validation_loss/len(data_loader.dataset), validation_accuracy/len(data_loader.dataset)

# function to evaluate model without plots using testing or validation datasets
def evaluate(model, data_loader):
    """
        Function to create a prediction based on test images using a trained model.
        Output will be the np.array of predicted labels.
    
    Args:
        model: The trained model.
        data_loader: Subsamples over the test dataset. 
    
    """
    model.eval()
    y_preds = []
    for X in data_loader:
        with torch.no_grad():
            
            X = X.to(device)
            a2 = model(X.view(-1, 3, 224 , 224))                                                          
            y_pred = F.log_softmax(a2, dim=1).max(1)[1]
            y_preds.append(y_pred.cpu().numpy())
            
    return np.concatenate(y_preds, 0)


# In[8]:


# import pre-trained model from pytorch
# ResNet-50 model from "Deep Residual Learning for Image Recognition" <https://arxiv.org/pdf/1512.03385.pdf>`
#resnet50 = models.resnet50(pretrained=True, progress=True)

def set_parameter_requires_grad(model):
    """
    Function to set the gradient requirement of the parameters to pre-trained model to False.
    This thuerefore allows us to do feature extraction.
    
    Args:
    model: imported pre-trained classifier model from pytorch library.
        
    """
    for param in model.parameters():
        param.requires_grad = False

        
#function to initialize imported model
def initialize_model(num_classes, use_pretrained=True):
    """
    Function to initialise Pre-trained ResNet50 model.
    The pre-trained parameters improves the overall accuracy of the model.
    The method used was feature extraction.
    
        Args:
        num_classes: Set to 200 globally.
        Use_pretrained: A bool. Default using pre-trained model. 
        
    """
    set_parameter_requires_grad(resnet50)
    fc_inputs = resnet50.fc.in_features
    resnet50.fc = nn.Sequential(
        nn.Linear(fc_inputs, num_classes))
    
    return resnet50
#
##set the number of output classes
#num_classes = 200 
#resnet50 = initialize_model(num_classes, use_pretrained=True)
#
## Send the model to GPU
#resnet50 = resnet50.to(device)
#
##the parameters to be optimized
#params_to_update = resnet50.parameters()
#
#
## In[9]:
#
#
## hyperparameters
#seed = 42
#lr = 2e-3
#momentum = 0.9
#batch_size = 128
#test_batch_size = 500
#n_epochs = 10
#weight_decay = 1e-2
#
#
## In[10]:
#
#
# setup defined randomness
#set_seed(seed)

# initialize optimizer
#optimizer_ft = optim.SGD(params_to_update, lr=lr, momentum=momentum)

# define loss function to be used for training
#criterion = nn.CrossEntropyLoss()


# In[11]:


# main training loop function for training and validation sets
def train_pret_model(momentum):
    """
    Function to train model on the train and validation dataset.
    
    Args:
        momentum: momentum parameter of the SGD optimizer. 
    
    """
    liveloss = PlotLosses()
    for epoch in range(n_epochs):
        logs = {}
        train_loss, train_accuracy = train(resnet50, optimizer_ft, criterion, train_loader)

        logs['' + 'log loss'] = train_loss.item()
        logs['' + 'accuracy'] = train_accuracy.item()

        validation_loss, validation_accuracy = validate(resnet50, criterion, validation_loader)
        logs['val_' + 'log loss'] = validation_loss.item()
        logs['val_' + 'accuracy'] = validation_accuracy.item()

        liveloss.update(logs)
        liveloss.draw()
        torch.save(resnet50.state_dict(), "./val_train2_e%s.pth" % epoch)

    return resnet50


# In[11]:


# train and validate
#model = train_pret_model(momentum)


# In[13]:


# reinitializing the model import for full training set
# ResNet-50 model from "Deep Residual Learning for Image Recognition" <https://arxiv.org/pdf/1512.03385.pdf>`
#resnet50 = models.resnet50(pretrained=True, progress=True)

def set_parameter_requires_grad(model):
    """
    Function to set the gradient requirement of the parameters to pre-trained model to False.
    
    Args:
    model: imported pre-trained classifier model from pytorch library.
        
    """
    for param in model.parameters():
        param.requires_grad = False


#function to initialize imported model
def initialize_model(num_classes, use_pretrained=True):
    """
    Function to initialise Pre-trained ResNet50 model.
    The pre-trained parameters improves the overall accuracy of the model at low epochs.
    The method used was feature extraction.

        Args:
        num_classes: Set to 200 globally.
        Use_pretrained: A bool. Default using pre-trained model. 
        
    """
    set_parameter_requires_grad(resnet50)
    fc_inputs = resnet50.fc.in_features
    resnet50.fc = nn.Sequential(
        nn.Linear(fc_inputs, num_classes))
    
    return resnet50
#
##set the number of output classes
#num_classes = 200 
#resnet50 = initialize_model(num_classes, use_pretrained=True)
#
## Send the model to GPU
#resnet50 = resnet50.to(device)
#
##the parameters to be optimized
#params_to_update = resnet50.parameters()
#
## setup defined randomness
#set_seed(seed)
#
## initialize optimizer
#optimizer_ft = optim.SGD(params_to_update, lr=lr, momentum=momentum)
#
## define loss function to be used for training
#criterion = nn.CrossEntropyLoss()
#
#
## In[14]:
#
#
## reset training dataloader for the full training set
#train_loader = DataLoader(full_data, batch_size=batch_size, shuffle=True, num_workers=0)
#
# main training loop function for full training set
def full_train(momentum):
    """
    Function to train model on the whole training dataset.
    
    Args:
        momentum: momentum parameter of the SGD optimizer. 
    
    """
    liveloss = PlotLosses()
    for epoch in range(10):
        logs = {}
        train_loss, train_accuracy = train(resnet50, optimizer_ft, criterion, train_loader)

        logs['' + 'log loss'] = train_loss.item()
        logs['' + 'accuracy'] = train_accuracy.item()

        liveloss.update(logs)
        liveloss.draw()
        torch.save(resnet50.state_dict(), "./full_train2_e%s.pth" % epoch)
    return resnet50
#
#
## In[14]:
#
#
## full training
#model = full_train(momentum)
#
#
## In[18]:
#
#
## get predicted class using trained model
#y_pred = evaluate(model, test_loader)
#
#
## In[15]:
#
#
## function to write results of predicted class into csv format
## path_to_test should be defined by user to direct to where the test images folder is
## exmaple: path_to_test = './data/test/images/'
## note: the "/" at the end of path is required
#path_to_test = './data/test/images/'
#path_len = len(path_to_test)
#
def write_csv(csv_name):
    """
    Function to output filename and predicted label of test images into csv format.
    First column is the filename, second column is the label in integer of the 200 classes.
    Headers are included as "Filename" and "Label"
    
    Args:
        csv_name: desired name of the output csv file. 
    
    """
    with open(csv_name, 'w', newline='') as newFile:
        
        writer = csv.writer(newFile, lineterminator='\n')
        writer.writerow(("Filename","Label"))
        i = 0 
        for y in y_pred:
            writer.writerow((test_data_raw[i][2][path_len:-4] + 'jpeg', y.astype("U")))
            i += 1        

    return 0


# In[26]:


# defining the name of desired csv file then call function
#csv_name = 'full22.csv'
#write_csv(csv_name)


# In[16]:


# function to print out the content of created csv file from function write_csv(csv_name) to double check format
def print_csv(csv_name):
    """
    Function to print out and test the csv file output is in the right format.
    
    Args:
        csv_name: the csv file name to be read and tested. 
    
    """
    with open(csv_name) as csv_file:
        
        csv_reader = csv.reader(csv_file, delimiter=',')
        line_count = 0
        for row in csv_reader:
            print(row)
            
    return 0


# In[28]:


# call function and print the csv file generated
#print_csv(csv_name)

