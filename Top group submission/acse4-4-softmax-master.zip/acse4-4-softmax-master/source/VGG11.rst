.. automodule:: python_models.VGG11
  :members:
  
