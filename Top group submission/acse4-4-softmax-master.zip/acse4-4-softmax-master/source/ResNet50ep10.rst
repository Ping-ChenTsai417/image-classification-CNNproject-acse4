.. automodule:: python_models.ResNet50ep10
  :members: