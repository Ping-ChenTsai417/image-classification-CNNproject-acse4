# This code was runned on Kaggle Server

import os
path = '../input/acse-miniproject/'
# os.listdir(path)

!pip install torch pycm livelossplot torchvision torchtoolbox
%pylab inline
from sklearn.metrics import accuracy_score

from livelossplot import PlotLosses
from pycm import *

from PIL import Image
import torch
import torchvision
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import TensorDataset, DataLoader, random_split
import torchvision.transforms as transforms
from torchtoolbox.transform import Cutout

def set_seed(seed):
    """
    Use this to set ALL the random seeds to a fixed value and take out any randomness from cuda kernels
    """
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

    torch.backends.cudnn.benchmark = False  ##uses the inbuilt cudnn auto-tuner to find the fastest convolution algorithms. -
    torch.backends.cudnn.enabled   = False

    return True

device = 'cpu'
if torch.cuda.device_count() > 0 and torch.cuda.is_available():
    print("Cuda installed! Running on GPU!")
    device = 'cuda'
else:
    print("No GPU available!")
    
from sklearn.model_selection import StratifiedShuffleSplit
from torchvision.datasets import ImageFolder

# default means and stds from the ImageNet
means = [0.485, 0.456, 0.406]
stds = [0.229, 0.224, 0.225]

# Resize the images to 3x224x224 and normalise them
train_normalise = transforms.Compose([
                    transforms.Resize(224),
#                     transforms.RandomErasing(ratio=(1.0, 1.0), value=0),
#                     transforms.ToPILImage(),
#                     transforms.RandomHorizontalFlip(),
                    transforms.ToTensor(),
                    transforms.Normalize(mean=np.array(means), std=np.array(stds))])

test_normalise = transforms.Compose([
                    transforms.Resize(224),
                    transforms.ToTensor(),
                    transforms.Normalize(mean=np.array(means), std=np.array(stds))])

# split data
full_data = ImageFolder(path+'train', transform=train_normalise)
train_size = int(0.8 * len(full_data))
validation_size = len(full_data) - train_size
train_dataset, validation_dataset = random_split(full_data, [train_size, validation_size])

# define train, validation, evaluation function
def train(model, optimizer, criterion, data_loader):
    model.train()
    train_loss, train_accuracy = 0, 0
    i = 0
    for X, y in data_loader:
        i += 1
        if i % 100 == 0:
            print(i)
        X, y = X.to(device), y.to(device)
        optimizer.zero_grad()
        a2 = model(X.view(-1, 3, 224, 224)) #modification described above
        loss = criterion(a2, y)
        loss.backward()
        train_loss += loss*X.size(0)
        y_pred = F.log_softmax(a2, dim=1).max(1)[1]
        train_accuracy += accuracy_score(y.cpu().numpy(), y_pred.detach().cpu().numpy())*X.size(0)
        optimizer.step()  
        
    return train_loss/len(data_loader.dataset), train_accuracy/len(data_loader.dataset)
  
def validate(model, criterion, data_loader):
    model.eval()
    validation_loss, validation_accuracy = 0., 0.
    for X, y in data_loader:
        with torch.no_grad():
            X, y = X.to(device), y.to(device)
            a2 = model(X.view(-1, 3, 224, 224)) #modification described above
            loss = criterion(a2, y)
            validation_loss += loss*X.size(0)
            y_pred = F.log_softmax(a2, dim=1).max(1)[1]
            validation_accuracy += accuracy_score(y.cpu().numpy(), y_pred.cpu().numpy())*X.size(0)
            
    return validation_loss/len(data_loader.dataset), validation_accuracy/len(data_loader.dataset)

def evaluate(model, data_loader):
    model.eval()
    y_preds = []
    i = 0
    for X in data_loader:
        i += 1
        print(i)
        with torch.no_grad():
            X = X[0].to(device)
            a2 = model(X.view(-1, 3, 224 , 224))                                                                                # ARH # Resize to 254x 254 to be able fit into model                                                              
            y_pred = F.log_softmax(a2, dim=1).max(1)[1]
            y_preds.append(y_pred.cpu().numpy())                                                                                
    return np.concatenate(y_preds, 0)

# model definitions
import torch.optim as optim
import torchvision.models as models


pretrained_model = models.densenet201(pretrained=True, progress=True)
def set_parameter_requires_grad(model):
    for param in model.parameters():
        param.requires_grad = False

#function to initialize
def initialize_model(num_classes, use_pretrained=True):
    set_parameter_requires_grad(pretrained_model)
    #fc_inputs = resnet18.fc.in_features
    pretrained_model.classifier = nn.Sequential(nn.Linear(1920, 200))
    return pretrained_model

num_classes = 200 #set the number of classes
pretrained_model = initialize_model(num_classes, use_pretrained=True)

# Send the model to GPU
pretrained_model = pretrained_model.to(device)

#hyperparameters provided
seed = 42
lr = 1e-2
momentum = 0.5
batch_size = 128
test_batch_size = 500
n_epochs = 10
weight_decay = 0

#initialize optimizer
optimizer_ft = optim.SGD(pretrained_model.parameters(), lr=lr, momentum=momentum)

set_seed(seed)
criterion = nn.CrossEntropyLoss()

# train and validation progress
def train_pret_model(momentum):
    set_seed(seed)
    pre_optimizer = torch.optim.SGD(pretrained_model.parameters(), lr=lr, momentum=momentum, weight_decay=weight_decay)
    criterion = nn.CrossEntropyLoss() #define the loss function (L2 regularization used)

    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=0)
    validation_loader = DataLoader(validation_dataset, batch_size=test_batch_size, shuffle=False, num_workers=0)
  
    liveloss = PlotLosses()

    print("Start!")
    
    for epoch in range(n_epochs):
        logs = {}
        train_loss, train_accuracy = train(pretrained_model, optimizer_ft, criterion, train_loader)

        logs['' + 'log loss'] = train_loss.item()
        logs['' + 'accuracy'] = train_accuracy.item()

        validation_loss, validation_accuracy = validate(pretrained_model, criterion, validation_loader)
        logs['val_' + 'log loss'] = validation_loss.item()
        logs['val_' + 'accuracy'] = validation_accuracy.item()

        liveloss.update(logs)
        liveloss.draw()
        torch.save(pretrained_model.state_dict(), "./model_50_e%s.pth" % epoch)

    return pretrained_model

# start training
model = train_pret_model(0.5)
